﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public interface IMainForm
    {
        string FilePath { get; }
        string Content { get; set; }
        void SetSymbolCount(int count);

        event EventHandler FileOpenClick;
        event EventHandler FileSaveClick;
        event EventHandler ContentChanged;
    }

    public partial class Form1 : Form, IMainForm
    {
        public Form1()
        {
            InitializeComponent();

            //создание и подписка на событие
            openFileButton.Click += new EventHandler(openFileButton_Click);
            saveButton.Click += new EventHandler(saveButton_Click);
            fldContent.TextChanged += new EventHandler(fldContent_TextChanged);
            selectFileButton.Click += selectFileButton_Click;
            numFont.ValueChanged += numFont_ValueChanged;
        }

        //события

        public event EventHandler FileOpenClick;
        public event EventHandler FileSaveClick;
        public event EventHandler ContentChanged;

        //проброс событий
        private void openFileButton_Click(object sender, EventArgs e)
        {
            if (FileOpenClick != null)
            {
                FileOpenClick(this, EventArgs.Empty);
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (FileSaveClick != null)
            {
                FileSaveClick(this, EventArgs.Empty);
            }
        }

        private void fldContent_TextChanged(object sender, EventArgs e)
        {
            if (ContentChanged != null)
            {
                ContentChanged(this, EventArgs.Empty);
            }
        }

        //реализация интерфейса
        public string FilePath 
        { 
            get 
            {
                return textBox1.Text;
            }
        }

        public string Content
        {
            get
            {
                return fldContent.Text;
            }
            set
            {
                fldContent.Text = value;
            }
        }

        public void SetSymbolCount(int count)
        {
            lblSymbolCount.Text = count.ToString();
        }


        //код формы
        private void selectFileButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "...|*.txt";

            if(dlg.ShowDialog() == DialogResult.OK)
            {
                toolStripStatusLabel1.Text = dlg.FileName;

                if (FileOpenClick != null)
                {
                    FileOpenClick(this, EventArgs.Empty);
                }
            }
        }

        private void numFont_ValueChanged(object sender, EventArgs e)
        {
            fldContent.Font = new Font("Calibri", (float)numFont.Value);
        }

        ////как будут работать события
        //кликаем на кнопку file open
        //попадаем в обработчик события этой кнопки - непосредственно в метод openFileButton_Click(object sender, EventArgs e)
        //проверяем есть ли подписчики у нашего собственного события FileOpenClick (FileOpenClick != null)
        //если есть, то вызываем FileOpenClick(this, EventArgs.Empty);
    }
}
